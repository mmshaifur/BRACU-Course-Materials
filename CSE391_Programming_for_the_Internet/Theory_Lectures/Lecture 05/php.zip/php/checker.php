<?php
/*declare some function*/
function print_form($f_name, $l_name, $email, $os)
{
?>

 <form action="form_checker.php" method="post">
 First Name: <input type="text" name="f_name" value="<?php print $f_name?>"> <br/>
 Last Name <b>*</b>:<input type="text" name="l_name" value="<?php print $l_name?>"> <br/>
 Email Address <b>*</b>:<input type="text" name="email" value="<?php print $email?>"> <br/>
 Operating System: <input type="text" name="os" value="<?php print $os?>"> <br/>
 <input type="submit" name="submit" value="Submit"><input type="Reset">
 </form>

<?
}

function ckeck_form($f_name, $l_name, $email, $os)
{
  if (!$l_name||!$email){
  echo "<h3>You are missing some required fields!</h3>";
  print_form($f_name, $l_name, $email, $os);
  }
  else{
  confirm_form($f_name, $l_name, $email, $os);
  }
}


function confirm_form($f_name, $l_name, $email, $os)
{
?>

<h2>Thanks! Below is the information you have sent to us.</h2>
<h3>Contact Info</h3>

<?
echo "Name: $f_name $l_name <br/>";
echo "Email: $email <br/>";
echo "OS: $os";

}

/*Main Program*/

if (!$submit)
{
 ?>
 <h3>Please enter your infromation<h3>
 <p>Fields with a "<b>*</b>" are required.</p>

<?php
 print_form("","","","");
}
else{
 check_form($f_name,l_name,$email,$os);
}
?>


</body>
</html>
