<html><head></head>
<body>

<?php
$nextWeek = time() + (7 * 24 * 60 * 60);
                   // 7 days; 24 hours; 60 mins; 60secs
echo "<h3> Now:      ". date('Y-m-d') ."</h3> \n";
echo "<h3> Next Week: ". date('Y-m-d', $nextWeek) ."</h3> \n";
?>

</body>
</html>
