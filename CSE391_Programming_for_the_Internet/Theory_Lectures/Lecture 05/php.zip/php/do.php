<html><head></head>
<!-- do.php -->
<body>

<?php 
$i=0;
do
{
$i++;
echo "The number is " . $i . "<br />";
}
while($i <= 10);
?>

</body>
</html>
