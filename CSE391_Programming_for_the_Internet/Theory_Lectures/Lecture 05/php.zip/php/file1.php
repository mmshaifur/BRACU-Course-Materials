<html><head></head>
<!-- file1.php -->
<body>

<?php
$myFile = "welcome.txt";
if (!($fh=fopen($myFile,'r'))) exit("Unable to open file.");
while (!feof($fh))
{ 
$x=fgetc($fh); 
echo $x;
}
fclose($fh);
?>

</body>
</html>
