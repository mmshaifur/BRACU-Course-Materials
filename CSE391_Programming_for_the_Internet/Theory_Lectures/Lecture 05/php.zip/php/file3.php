<html><head></head>
<!-- file3.php -->
<body>

<?php
$lines = file('welcome.txt');
foreach ($lines as $l_num => $line) 
{
 echo "Line #{$l_num}: ".$line."<br/>";
}
?>

</body>
</html>
