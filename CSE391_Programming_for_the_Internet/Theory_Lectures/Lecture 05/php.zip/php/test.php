<html><head></head>
<!-- test.php -->
<body>

<?php

echo "<h3> A $color $fruit <h3>"; // A

include 'vars.php';

echo "<h3> A $color $fruit <h3>"; // A green apple

?>

</body>
</html>
