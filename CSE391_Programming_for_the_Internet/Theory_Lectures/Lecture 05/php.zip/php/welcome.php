<html>
<!-- welcome.php -->
<body>

Welcome <?php echo $_POST["name"]."."; ?> <br />
You are <?php echo $_POST["age"]; ?> years old!

</body>
</html>
