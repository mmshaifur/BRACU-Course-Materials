<html><head></head>
<!-- while.php -->
<body>

<?php 
$i=1;
while($i <= 5)
{
echo "The number is " . $i . "<br /> \n";
$i++;
}
?>

</body>
</html>
