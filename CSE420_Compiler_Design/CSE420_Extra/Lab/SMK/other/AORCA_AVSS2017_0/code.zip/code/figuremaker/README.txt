FIGUREMAKER - Publication quality figures with matlab
Version 2.1 July-22-2013
=====================================================

This package helps the user make publication quality figures in matlab. See 
INSTALL.txt for installation instructions and Contents.m for information 
about the package.