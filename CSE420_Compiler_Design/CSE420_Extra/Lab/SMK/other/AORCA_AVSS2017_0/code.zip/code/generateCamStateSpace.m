
% Brief: This function generates the state/velcoticy space of a mobile camera given its current state 
% Input: 
%       current state 
% Output:
%       stateSpace: mobile camera state space
%       preVelo: velocity space
%       cu_v: control space of speed
%       cu_sa: control space of steering angle
%       aMax: acceleraton limit vector
%       vMax: velocity limite vector
% Author: Yiming Wang - yiming.wang@qmul.ac.uk OR wangyimingkaren@gmail.com
% No permission necessary for non-commercial use
% Date: 27/08/2017

function [stateSpace,preVelo,cu_v,cu_sa,aMax,vMax] = generateCamStateSpace(currentState)
    load cameraSettings
    global dT freq vmax
    aMax = [vmax;0.2*pi;0.2*pi]; % 36 degrees 
    vMax = [vmax;0.2*pi;0.2*pi]; 

    cu_v_min = max(-aMax(1),-vMax(1)-currentState(5));
    cu_v_max = min(aMax(1),vMax(1)-currentState(5));


    cu_sa_min = max(-aMax(2),-vMax(2)-currentState(6));
    cu_sa_max =  min(aMax(2),vMax(2)-currentState(6));

    cu_v = cu_v_min:0.05:cu_v_max;
    cu_sa = cu_sa_min:0.005*pi:cu_sa_max;

    [cu_SA,cu_V] = meshgrid(cu_sa,cu_v);
    cu_PA = zeros(size(cu_SA));

    delta_t = dT/freq;
    delta_ts = 0.5*delta_t^2;

    controlSpace = [cu_V(:) cu_SA(:) cu_PA(:)];

    currentStateMatrix = repmat(currentState',size(cu_V(:),1),size(cu_V(:),2));

    % accelerate uniformly for 10 times 
    for times = 1:freq
        stateSpace = cameraStateUpdateMatrix(currentStateMatrix,controlSpace,delta_t,delta_ts,L);
        currentStateMatrix = stateSpace;
    end
    
   % the actual moved velocity (position difference)
   preVelo = [stateSpace(:,1)-currentState(1), stateSpace(:,2)-currentState(2)];
   %preVelo = polor_cartsian(stateSpace(:,5),stateSpace(:,3));
end

