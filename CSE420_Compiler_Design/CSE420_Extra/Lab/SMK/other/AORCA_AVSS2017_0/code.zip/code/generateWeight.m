% Brief: This function generates the weight based on the color given to each target
% Input: 
%       number of targets 
%       target colour
% Output: 
%       the weight of the target
% Author: Yiming Wang - yiming.wang@qmul.ac.uk OR wangyimingkaren@gmail.com
% No permission necessary for non-commercial use
% Date: 27/08/2017


function tarWeight = generateWeight( Nt,tarColor)
tarWeight = zeros(Nt,1);
for i = 1:Nt
    tarWeight(i) = sum(tarColor{i});
end
end

