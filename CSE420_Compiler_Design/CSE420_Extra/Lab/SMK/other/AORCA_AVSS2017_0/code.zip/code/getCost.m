
% Brief: This function computes the cost, i.e. cost for view qualtiy(J1), and cost for motion smoothness(J2) and the sum of both costs (J) 
% Input: the current camera state, the state of target and the new camera state
% Output: J1, J2 and J
% Author: Yiming Wang - yiming.wang@qmul.ac.uk OR wangyimingkaren@gmail.com
% No permission necessary for non-commercial use
% Date: 27/08/2017

function [j1,j2,j] = getCost(currentstate,targetState,cameraState)
global viewAngle viewDistance vmax lambda
    % bearing angle of mobile respect to target 
    predictTargetState = predictTarState4D(targetState,1);
    cameraOrienAngle = orienAngleAB(predictTargetState(1:2)',[cameraState(1),cameraState(2)]);
    preVelo = polor_cartsian(cameraState(5),cameraState(3));
    currentVelo = polor_cartsian(currentstate(5),currentstate(3));
    % bearing angle of target respect to a camera

    deltaAngle = 0*viewAngle; 

    tarOrienAngle = cameraOrienAngle + pi*(cameraOrienAngle<pi)- pi*(cameraOrienAngle>=pi)-deltaAngle;
    absAngleDif = abs(tarOrienAngle-cameraState(4));
    % angle difference
    angleDif = min(absAngleDif,2*pi-absAngleDif);

    if sum(angleDif>pi)
        disp('ERROR: The angle difference should not be bigger than pi!!');
        pause();
    end

    viewAngleRatio = 2*angleDif/viewAngle;

    distCam2Tar_X = cameraState(1)- predictTargetState(1);
    distCam2Tar_Y = cameraState(2)- predictTargetState(2);

    distCam2Tar = sqrt(distCam2Tar_X.^2 + distCam2Tar_Y.^2);
    distanceRatio = abs(distCam2Tar-0.5*viewDistance)/(0.5*viewDistance);

    viewingRatio = sqrt(distanceRatio.^2 + viewAngleRatio.^2);

    distance_to_currentVelo_x = preVelo(1) - currentVelo(1);
    distance_to_currentVelo_y = preVelo(2) - currentVelo(2);
    distance_to_currentVelo_Magnitude = sqrt(distance_to_currentVelo_x.^2 + distance_to_currentVelo_y.^2);
    
    distance_to_currentVelo_difRatio = distance_to_currentVelo_Magnitude./(vmax+abs(currentstate(5)));
    
    if sum(isnan(distance_to_currentVelo_difRatio))
        pause(1);
        disp(vmax+currentstate(5));
    end
   
   
    if viewingRatio<0|distance_to_currentVelo_difRatio<0
        disp(viewingRatio);
    end
    j1 = exp(1).^(viewingRatio);
    j2 = exp(1).^distance_to_currentVelo_difRatio;
    
    j = lambda*j1+(1-lambda)*j2;
end

