function printDebugInfo( string )
global DEBUG
if DEBUG
    disp(['DEBUG::' string]);
end
end

