clc;
x=[-5:0.01:5];
y=x.^4 + 2.5*x.^3 + 2.5*x.^2 + 10*x - 228;
figure();
plot(x,y), grid on;
roots([1 2.5 2.5 10 -228])