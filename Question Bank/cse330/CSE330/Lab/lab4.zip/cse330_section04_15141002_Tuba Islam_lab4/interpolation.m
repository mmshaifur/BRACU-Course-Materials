clc;
clear all;
x=[0 1 2 3 4 5];
y=[0 0.5 0.8 0.90 0.941 0.962];
interp1(x,y,3.5,'spline')
interp1(x,y,3.5,'nearest')
interp1(x,y,3.5,'linear')