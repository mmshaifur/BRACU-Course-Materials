clc;
clear all;
x=[0 20 40];
y=[7 0.8 0.212];
l=zeros(length(x),length(x))
for i=1:length(x)
    v=1;
    for k=1:length(x)
        if i~=k
        u=roots(v)
        j=roots((x-x(k))/(x(i)-x(k)))
       p =conv(poly(u),poly(j))
       v=p;

       
        end
  
    end
      l(i,:)=p
end

for i=1:length(x)
l(i,:)=l(i,:).*y(i)
end
disp(l)
