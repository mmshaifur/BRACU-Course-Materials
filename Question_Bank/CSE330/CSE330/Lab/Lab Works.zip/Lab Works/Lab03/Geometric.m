function[sum] = Geometric(r,n);
sum=0;
for i=0:n
    sum = sum + (r^i);
end