function[O] = Product(X,Y)
O = zeros(3,3);
for i=1:3
    for j=1:3
        val=X(i,j);
        sum=0;
        for k=1:3
            sum = sum + (val*Y(k,i));
        end
        O(i,j)=sum;
    end
end