function[result] = Summ(a,b);
result=a+b;
