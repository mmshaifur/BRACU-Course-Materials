clc;
max_iter=50;
tol=.00001;
x=0;
p(1)=0;
for k=1:max_iter
    p(k+1)=exp(-p(k));
    err=abs((p(k+1)-p(k))/p(k+1));
    if(err< tol)
        soln=p(k+1);
        break;
    end
end
soln=p(k+1)
