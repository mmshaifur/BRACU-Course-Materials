function [root, ea, iter]= Bisection(f, xl, xu, es, maxit)

    if (f(xl)*f(xu))<0
        xm=(xl+xu)/2;
        for i=0:maxit
            if(f(xl)*f(xm))== 0
                root = xm;
                break
            end
            
            if (f(xl)*f(xm))<0
                xu=xm;
            else 
                xl=xm;
            end
            
            if xl~=0
            ea=abs(((xu-xl)/xu)*100);
            end
            
            if ea<=es || i>=maxit
            break
            end
        end
    end
root = xm;
disp(root, ea, i);
           

    