function[O] = ConvertTemp(ti, tf)
iter= tf-ti+1;
O = zeros(iter,2);
for i=1:iter
    if(ti<=tf)
        conv=(ti*1.8)+32;
        O(i,1) = ti;
        O(i,2) = conv;
        ti = ti + 1;
    end
end
disp(O);
    
