clc;

r = [ 5-2i; 2+3i; 5; 5+2i; 2-3i];
A = poly(r)
polyval(A,2)