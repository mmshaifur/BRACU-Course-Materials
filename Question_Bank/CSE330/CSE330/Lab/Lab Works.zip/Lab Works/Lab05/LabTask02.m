clc; 
X = [ 200 250 300 350 400 450];
Y = [ 1.708 1.367 1.139 0.967 0.854 0.759];

y220 = interp1(X,Y,220,'spline')
y279 = interp1(X,Y,279,'spline')
y370 = interp1(X,Y,370,'spline')