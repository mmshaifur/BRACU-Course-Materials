clc;
A=[4 3 -2 1 6];
B=[3 0 -5 9];
C=conv(A,B)
root_A=roots(A)
root_B=roots(B)
root_C=roots(C)
