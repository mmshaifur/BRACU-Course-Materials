clc;
maxit=100;
t=.00001;
x=0;
p(1)=0;
for i=1:maxit
    p(i+1)=sqrt(x)+sqrt(sin(radtodeg(x+.15)));
    err=abs((p(i+1)-p(i))/p(i+1));
    
    if(err<t)
        ans3=p(i+1);
        break
    end
end
ans3=p(i+1);
disp(ans3)
disp(err)