a = 2.34;
b = 3.7;
c = 3.95;
d = 7;

ansA = sqrt(2*a*c)-(4*cos(pi/2))+ factorial(d);
disp(ansA)

ansB = (5*b^3)-floor(d/a)+round(real(7+5i));
disp(ansB)

ansC = ((log10(b)*log10(c))/exp(a)) + abs(15-(2*d));
disp(ansC)

ansD = sqrt(sqrt(81*3*pi*c));
disp(ansD);