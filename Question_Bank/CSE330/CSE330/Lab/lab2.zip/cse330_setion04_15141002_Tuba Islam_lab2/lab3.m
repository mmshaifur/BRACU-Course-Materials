clc;
fact=1;
for i=1:1:10
    fact=fact*i;
end
disp('factorial of 10 is : '),disp(fact)

a=[-2 4 -6 0 2 8 9];
sum=0;
for i=1:1:7
    sum=sum+a(i);
end
avg=sum/7;
x=0;
for j=1:1:7
    x=x+(a(j)-avg).^2;
end
var=x/7;
disp(var)

    