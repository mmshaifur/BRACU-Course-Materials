
function y=celcius(ti,tf)
c=zeros(ti,2);
for i=ti:1:tf
         c(i,1)=i;
         c(i,2)=i*8.5+32;
         
end

y=c
