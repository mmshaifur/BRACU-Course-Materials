clc;
clear all
x=[1 2 3; 4 5 6 ; 7 8 9];
y=[3 2 1; 6 5 4;9 8 7];
c=zeros(3,3);
    for j=1:1:3
        for k=1:1:3
           
                c(j,k)=x(j,:)*y(:,k)           
        end
    end
disp(c)
            